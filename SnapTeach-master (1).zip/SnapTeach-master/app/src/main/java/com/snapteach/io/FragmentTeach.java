package com.snapteach.io;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.net.URI;
import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;

/**
 * Created by HP on 06-10-2017.
 */

public class FragmentTeach extends Fragment {

    private Uri selectedImage;
    private static int RESULT_LOAD_IMAGE = 1;
    private StorageReference mStorage;
    private String imgId;
    private String name;
    private String cost;
    private Button addLecture;
    private Button addPrereq;
    private EditText lecture;
    private EditText prereq;
    private EditText courseName;
    private FirebaseAuth mFirebaseAuth;
    private EditText courseCost;
    private Button submitLecture;
    private ArrayList<String> listLectures = new ArrayList<String>();
    private ArrayList<String> listPrereq = new ArrayList<String>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        return inflater.inflate(R.layout.fragment_teach, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle("Teach");
        mFirebaseAuth = FirebaseAuth.getInstance();
        mStorage = FirebaseStorage.getInstance().getReference();
        Button imageUpload =(Button) view.findViewById(R.id.imageUpload);
        imageUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });

        addLecture = (Button) getView().findViewById(R.id.addLectures);
        addPrereq = (Button) getView().findViewById(R.id.addPrereqs);
        submitLecture = (Button) getView().findViewById(R.id.submitLecture);
        lecture = (EditText) getView().findViewById(R.id.lecturesEditText);
        prereq = (EditText) getView().findViewById(R.id.prereqsEditText);
        courseName = (EditText) getView().findViewById(R.id.courseNameEditText);
        courseCost = (EditText)getView().findViewById(R.id.courseCostEditText);
        addPrereq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listPrereq.add(prereq.getText().toString());
                prereq.setText("");
            }
        });

        addLecture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listLectures.add(lecture.getText().toString());
                lecture.setText("");
            }
        });

        submitLecture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                name = courseName.getText().toString();
                cost = courseCost.getText().toString();

                CourseDBGenerator cdbg = new CourseDBGenerator();
                ArrayList<ArrayList<ArrayList<String>>> subscriptions = new ArrayList<ArrayList<ArrayList<String>>>();

                ArrayList<ArrayList<String>> basic = new ArrayList<ArrayList<String>>();
                ArrayList<ArrayList<String>> extra = new ArrayList<ArrayList<String>>();
                ArrayList<ArrayList<String>> miscl = new ArrayList<ArrayList<String>>();

                ArrayList<String> basic_lect = new ArrayList<String>();
                basic_lect.add("Basic lecture 1");
                basic_lect.add("15$/session");
                basic.add(basic_lect);

                ArrayList<String> extra_lect = new ArrayList<String>();
                extra_lect.add("Extra lecture 1");
                extra_lect.add("Free");
                extra.add(extra_lect);

                ArrayList<String> miscl_lect = new ArrayList<String>();
                miscl_lect.add("Miscellaneous lecture 1");
                miscl_lect.add("Free");
                miscl.add(miscl_lect);


                subscriptions.add(basic);
                subscriptions.add(extra);
                subscriptions.add(miscl);
                cdbg.makeDatabase(0,name,mFirebaseAuth.getCurrentUser().getDisplayName(),mFirebaseAuth.getCurrentUser().getEmail(),Integer.parseInt(cost),imgId,listLectures,listPrereq,subscriptions);
                Toast.makeText(getContext(),"Succesful",Toast.LENGTH_SHORT).show();

                courseName.setText("");
                courseCost.setText("");
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);



        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
            selectedImage = data.getData();
            ImageView imgView = (ImageView)getView().findViewById(R.id.courseImage);
            imgView.setImageURI(selectedImage);
            imgId = selectedImage.getLastPathSegment();
            StorageReference filepath = mStorage.child(selectedImage.getLastPathSegment());
            filepath.putFile(selectedImage).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Uri downloadUrl = taskSnapshot.getDownloadUrl();
                    imgId = downloadUrl.toString();
                }
            });
        }

    }
}