package com.snapteach.io;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

/**
 * Created by jains on 29-10-2017.
 */

public class CourseDBGenerator {

    public DatabaseReference mDatabase;
    public long count;

    public CourseDBGenerator() {


    }

    public void makeDatabase(int cRating, String cName, String cInstructor, String cInstructorMail, int cCost, String cPID, ArrayList<String> cLectures, ArrayList<String> cPreReq, ArrayList<ArrayList<ArrayList<String>>> cSubscriptions) {

        mDatabase = FirebaseDatabase.getInstance().getReference();

        Course c = new Course();
        c.set_rating(cRating);
        c.set_courseName(cName);
        c.set_instructorName(cInstructor);
        c.set_instructorEmail(cInstructorMail);
        c.set_cost(cCost);
        c.set_photoID(cPID);
        c.set_lectures(cLectures);
        c.set_preRequisites(cPreReq);
        c.set_subscriptionOptions(cSubscriptions);

        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot d : dataSnapshot.child("Courses").getChildren()) {
                    count++;
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        mDatabase.child("Courses").push().setValue(c);

    }
}
