package com.snapteach.io;

import java.util.ArrayList;

/**
 * Created by jains on 29-10-2017.
 */

public class Course {

    public int _rating;
    public String _courseName;
    public String _instructorName;
    public String _instructorEmail;
    public int _cost;
    public String _photoID;
    public ArrayList<String> _lectures;
    public ArrayList<String> _preRequisites;
    public ArrayList<ArrayList<ArrayList<String>>> _subscriptionOptions;

    public String get_instructorEmail() {
        return _instructorEmail;
    }

    public void set_instructorEmail(String _instructorEmail) {
        this._instructorEmail = _instructorEmail;
    }

    public int get_rating() {
        return _rating;
    }

    public void set_rating(int _rating) {
        this._rating = _rating;
    }

    public String get_courseName() {
        return _courseName;
    }

    public void set_courseName(String _courseName) {
        this._courseName = _courseName;
    }

    public String get_instructorName() {
        return _instructorName;
    }

    public void set_instructorName(String _instructorName) {
        this._instructorName = _instructorName;
    }

    public int get_cost() {
        return _cost;
    }

    public void set_cost(int _cost) {
        this._cost = _cost;
    }

    public String get_photoID() {
        return _photoID;
    }

    public void set_photoID(String _photoID) {
        this._photoID = _photoID;
    }

    public ArrayList<String> get_lectures() {
        return _lectures;
    }

    public void set_lectures(ArrayList<String> _lectures) {
        this._lectures = _lectures;
    }

    public ArrayList<String> get_preRequisites() {
        return _preRequisites;
    }

    public void set_preRequisites(ArrayList<String> _preRequisites) {
        this._preRequisites = _preRequisites;
    }

    public ArrayList<ArrayList<ArrayList<String>>> get_subscriptionOptions() {
        return _subscriptionOptions;
    }

    public void set_subscriptionOptions(ArrayList<ArrayList<ArrayList<String>>> _subscriptionOptions) {
        this._subscriptionOptions = _subscriptionOptions;
    }
}
