package com.snapteach.io;

import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.astuetz.PagerSlidingTabStrip;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class DetailsActivity extends AppCompatActivity {

    private Course c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        c = FragmentLearn.course;

        final LayoutInflater inflater = getLayoutInflater();
        LinearLayout mainLayout = (LinearLayout) findViewById(R.id.detailsLayout);

        View v = inflater.inflate(R.layout.inflator_details, null);
        MyTextView heading = (MyTextView) v.findViewById(R.id.bar_heading);
        heading.setText(c.get_courseName());
        v.findViewById(R.id.bar_backButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(DetailsActivity.this, NavBarActivity.class);
                startActivity(in);
            }
        });



        Picasso.with(v.getContext()).load(Uri.parse(c.get_photoID())).resize(1280,720).into((ImageView) v.findViewById(R.id.coverImage));
        ((TextView) v.findViewById(R.id.nameInstructor)).setText(c.get_instructorName());
        TextView description = (TextView) v.findViewById(R.id.description);
        description.setText(c.get_courseName() + " | " + Integer.toString(c.get_cost()) + "/hour");
        ViewPager viewPager = (ViewPager) v.findViewById(R.id.detailViewPager);
        viewPager.setAdapter(new DetailsPagerAdapter(getFragmentManager(), c.get_courseName()));
        PagerSlidingTabStrip tabsStrip = (PagerSlidingTabStrip) v.findViewById(R.id.tabs);
        tabsStrip.setViewPager(viewPager);
        tabsStrip.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        v.findViewById(R.id.subscribeButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(DetailsActivity.this, PurchaseActivity.class);
                startActivity(in);
            }
        });


        mainLayout.addView(v);
    }
}
