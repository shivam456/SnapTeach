package com.snapteach.io;

import java.util.ArrayList;

/**
 * Created by HP on 29-10-2017.
 */

public class User {

    public String _userName;
    public ArrayList<Course> myCourses;

}
