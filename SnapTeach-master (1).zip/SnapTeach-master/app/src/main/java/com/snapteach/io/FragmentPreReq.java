package com.snapteach.io;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by jains on 06-10-2017.
 */

public class FragmentPreReq extends Fragment {

    public static final String ARG_PAGE = "ARG_PAGE";
    public Course c;
    private int mPage;

    public static FragmentPreReq newInstance(int page) {
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE, page);
        FragmentPreReq fragment = new FragmentPreReq();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPage = getArguments().getInt(ARG_PAGE);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_prereq, container, false);
        c = FragmentLearn.course;

        LinearLayout preReq = (LinearLayout) view.findViewById(R.id.prereqsLayout);

        for (int i = 0; i < c.get_preRequisites().size(); i++) {

            View v = inflater.inflate(R.layout.inflator_main_details, null);
            TextView tv = (TextView) v.findViewById(R.id.details);
            tv.setText(c.get_preRequisites().get(i));
            preReq.addView(v);


        }


        return view;
    }

}
