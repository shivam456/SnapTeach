package com.snapteach.io;

/**
 * Created by HP on 06-10-2017.
 */

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Belal on 18/09/16.
 */


public class FragmentLearn extends Fragment {

    private DatabaseReference mDatabase;
    public static Course course;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        return inflater.inflate(R.layout.fragment_learn, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different title
        getActivity().setTitle("Experts");
        final LinearLayout mainLayout = (LinearLayout) view.findViewById(R.id.fragment_learnMainLayout);
        final LayoutInflater inflater = getActivity().getLayoutInflater();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                    for (DataSnapshot e : dataSnapshot.child("Courses").getChildren()) {
                        final Course c = e.getValue(Course.class);
                        View v = inflater.inflate(R.layout.inflator_course, null);
                        ImageView rating1 = (ImageView) v.findViewById(R.id.rating1);
                        rating1.setImageResource(R.drawable.holo_star);
                        ImageView rating2 = (ImageView) v.findViewById(R.id.rating2);
                        rating2.setImageResource(R.drawable.holo_star);
                        ImageView rating3 = (ImageView) v.findViewById(R.id.rating3);
                        rating3.setImageResource(R.drawable.holo_star);
                        ImageView rating4 = (ImageView) v.findViewById(R.id.rating4);
                        rating4.setImageResource(R.drawable.holo_star);
                        ImageView rating5 = (ImageView) v.findViewById(R.id.rating5);
                        rating5.setImageResource(R.drawable.holo_star);
                        TextView instructorName = (TextView) v.findViewById(R.id.courseInstructor);
                        TextView courseName = (TextView) v.findViewById(R.id.courseName);
                        TextView couurseCost = (TextView) v.findViewById(R.id.courseCost);
                        ImageView courseImage = (ImageView) v.findViewById(R.id.courseImage);
                        LinearLayout rating = (LinearLayout) v.findViewById(R.id.rating);
                        int[] arr = {R.id.rating1, R.id.rating2, R.id.rating3, R.id.rating4, R.id.rating5};

                        int r = c.get_rating();
                        for (int i = 0; i < r; i++) {
                            ImageView im = (ImageView) v.findViewById(arr[i]);
                            im.setImageResource(R.drawable.fill_star);
                        }
                        instructorName.setText(c.get_instructorName());
                        courseName.setText(c.get_courseName());
                        couurseCost.setText(Integer.toString(c.get_cost())+"$/hour");
                        courseImage.setImageResource(R.mipmap.ic_launcher);

                        v.findViewById(R.id.details).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent in = new Intent(getActivity(), DetailsActivity.class);
                                in.putExtra("Course Name", c.get_courseName());
                                course = c;
                                startActivity(in);
                            }
                        });

                        int padding_in_dp = 24;
                        final float scale = getResources().getDisplayMetrics().density;
                        int padding_in_px = (int) (padding_in_dp * scale + 0.5f);


                        Picasso.with(v.getContext()).load(Uri.parse(c.get_photoID())).resize(1280,720).into(courseImage);
                        rating.setPadding(0,padding_in_px,0,0);
                        v.setPadding(padding_in_px, padding_in_px, padding_in_px, padding_in_px);
                        mainLayout.addView(v);
                    }


                }


            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

}