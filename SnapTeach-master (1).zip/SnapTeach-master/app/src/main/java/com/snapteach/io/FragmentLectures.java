package com.snapteach.io;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by jains on 06-10-2017.
 */

public class FragmentLectures extends Fragment {

    public static final String ARG_PAGE = "ARG_PAGE";
    public Course c;
    private int mPage;

    public static FragmentLectures newInstance(int page) {
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE, page);
        FragmentLectures fragment = new FragmentLectures();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPage = getArguments().getInt(ARG_PAGE);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lectures, container, false);
        c = FragmentLearn.course;

        LinearLayout lectures = (LinearLayout) view.findViewById(R.id.lecturesLayout);

        for (int i=0; i<c.get_lectures().size();i++) {

            View v = inflater.inflate(R.layout.inflator_main_details, null);
            TextView tv = (TextView) v.findViewById(R.id.details);
            tv.setText(c.get_lectures().get(i));
            lectures.addView(v);

        }

        return view;
    }

}
