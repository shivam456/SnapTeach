package com.snapteach.io;

import android.app.Fragment;
import android.app.FragmentManager;
import android.support.v13.app.FragmentPagerAdapter;

/**
 * Created by jains on 06-10-2017.
 */

public class DetailsPagerAdapter extends FragmentPagerAdapter {
    final int PAGE_COUNT = 2;
    private String tabTitles[] = new String[]{"Lectures", "PreRequisites"};
    private String courseName;

    public DetailsPagerAdapter(FragmentManager fm, String courseName) {
        super(fm);
        this.courseName = courseName;
    }

    @Override
    public int getCount() {
        return PAGE_COUNT;
    }

    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            return FragmentLectures.newInstance(1);
        } else
            return FragmentPreReq.newInstance(2);

    }

    @Override
    public CharSequence getPageTitle(int position) {
        // Generate title based on item position
        return tabTitles[position];
    }

}