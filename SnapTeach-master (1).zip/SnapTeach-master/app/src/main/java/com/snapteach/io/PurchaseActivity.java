package com.snapteach.io;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class PurchaseActivity extends AppCompatActivity {

    private Course c;
    private int[] subscriptionID = new int[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase);

        subscriptionID[0] = R.id.basicCourseLayout;
        subscriptionID[1] = R.id.extrasCoursesLayout;
        subscriptionID[2] = R.id.miscellaneousCourseLayout;
        final TextView price = (TextView) findViewById(R.id.totalAmount);
        ImageView less = (ImageView) findViewById(R.id.subtract);
        ImageView more = (ImageView) findViewById(R.id.add);
        ImageView back = (ImageView) findViewById(R.id.backArrow);
        Button buy = (Button) findViewById(R.id.placeOrderButton);
        final TextView counter = (TextView) findViewById(R.id.sessionCount);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(PurchaseActivity.this,DetailsActivity.class);
                startActivity(in);
            }
        });

        less.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int sum = Integer.parseInt(counter.getText().toString()) - 1;
                if (sum < 0) {
                    sum = 0;
                }
                counter.setText(Integer.toString(sum));
            }
        });

        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                counter.setText(Integer.toString(Integer.parseInt(counter.getText().toString()) + 1));
            }
        });


        buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(PurchaseActivity.this, ConfirmOrder.class);
                startActivity(in);
            }
        });

        c = FragmentLearn.course;

        LayoutInflater inflater = getLayoutInflater();
        for (int i = 0; i < c.get_subscriptionOptions().size(); i++) {

            LinearLayout optionLayout = (LinearLayout) findViewById(subscriptionID[i]);

            for (int j = 0; j < c.get_subscriptionOptions().get(i).size(); j++) {

                LinearLayout ll = new LinearLayout(getApplicationContext());
                ll.setOrientation(LinearLayout.HORIZONTAL);
                View v = inflater.inflate(R.layout.inflator_purchase, null);
                MyTextView mtv = (MyTextView) v.findViewById(R.id.option);
                final int amount;

                if (!c.get_subscriptionOptions().get(i).get(j).get(1).equalsIgnoreCase("Free")) {
                    amount = Integer.parseInt(c.get_subscriptionOptions().get(i).get(j).get(1).split("\\$")[0]);
                } else {
                    amount = 0;
                }
                for (int k = 0; k < c.get_subscriptionOptions().get(i).get(j).size(); k++) {

                    String s = c.get_subscriptionOptions().get(i).get(j).get(k);
                    if (k == 1) {
                        mtv.setText(mtv.getText().toString() + " (" + s + ")");
                    } else {
                        mtv.setText(s);
                    }

                }
                final CheckBox checkBox = v.findViewById(R.id.check);

                checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                        if(b) {
                            int initialPrice = Integer.parseInt(price.getText().toString().split(" ")[0]);
                            initialPrice = initialPrice + amount;
                            price.setText(Integer.toString(initialPrice)+" USD");
//                            counter.setText(Integer.toString(Integer.parseInt(counter.getText().toString()) + 1));
                        } else {

                            int initialPrice = Integer.parseInt(price.getText().toString().split(" ")[0]);
                            initialPrice = initialPrice - amount;
                            price.setText(Integer.toString(initialPrice)+" USD");
//                            counter.setText(Integer.toString(Integer.parseInt(counter.getText().toString()) - 1));
                        }
                    }
                });
                ll.addView(v);
                optionLayout.addView(ll);
            }


        }


    }
}
